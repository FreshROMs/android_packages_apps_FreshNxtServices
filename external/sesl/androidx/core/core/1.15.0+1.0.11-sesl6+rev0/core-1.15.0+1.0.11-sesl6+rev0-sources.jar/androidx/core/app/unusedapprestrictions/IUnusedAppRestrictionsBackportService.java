/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package androidx.core.app.unusedapprestrictions;
@androidx.annotation.RestrictTo(androidx.annotation.RestrictTo.Scope.LIBRARY)
public interface IUnusedAppRestrictionsBackportService extends android.os.IInterface
{
  /** Default implementation for IUnusedAppRestrictionsBackportService. */
  public static class Default implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService
  {
    /**
     * Checks whether permission revocation is enabled for the calling application.
     * 
     * <p>This API is only intended to work for the backported version of
     * permission revocation running on Android M-Q and will not work for Android
     * R+ versions of permission revocation. Only the Verifier on the device can implement this,
     * as that is the component responsible for auto-revoking permissions on M-Q devices.
     * 
     * @param callback An IUnusedAppRestrictionsBackportCallback object that will
     * be called with the results of this API
     */
    @Override public void isPermissionRevocationEnabledForApp(androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback callback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService interface,
     * generating a proxy if needed.
     */
    public static androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService))) {
        return ((androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService)iin);
      }
      return new androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_isPermissionRevocationEnabledForApp:
        {
          androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback _arg0;
          _arg0 = androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback.Stub.asInterface(data.readStrongBinder());
          this.isPermissionRevocationEnabledForApp(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Checks whether permission revocation is enabled for the calling application.
       * 
       * <p>This API is only intended to work for the backported version of
       * permission revocation running on Android M-Q and will not work for Android
       * R+ versions of permission revocation. Only the Verifier on the device can implement this,
       * as that is the component responsible for auto-revoking permissions on M-Q devices.
       * 
       * @param callback An IUnusedAppRestrictionsBackportCallback object that will
       * be called with the results of this API
       */
      @Override public void isPermissionRevocationEnabledForApp(androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isPermissionRevocationEnabledForApp, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_isPermissionRevocationEnabledForApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  public static final java.lang.String DESCRIPTOR = "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService";
  /**
   * Checks whether permission revocation is enabled for the calling application.
   * 
   * <p>This API is only intended to work for the backported version of
   * permission revocation running on Android M-Q and will not work for Android
   * R+ versions of permission revocation. Only the Verifier on the device can implement this,
   * as that is the component responsible for auto-revoking permissions on M-Q devices.
   * 
   * @param callback An IUnusedAppRestrictionsBackportCallback object that will
   * be called with the results of this API
   */
  public void isPermissionRevocationEnabledForApp(androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback callback) throws android.os.RemoteException;
}
