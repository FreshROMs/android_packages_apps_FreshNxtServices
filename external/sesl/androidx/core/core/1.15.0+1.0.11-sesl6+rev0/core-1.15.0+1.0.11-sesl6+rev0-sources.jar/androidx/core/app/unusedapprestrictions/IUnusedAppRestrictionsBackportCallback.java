/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package androidx.core.app.unusedapprestrictions;
@androidx.annotation.RestrictTo(androidx.annotation.RestrictTo.Scope.LIBRARY)
public interface IUnusedAppRestrictionsBackportCallback extends android.os.IInterface
{
  /** Default implementation for IUnusedAppRestrictionsBackportCallback. */
  public static class Default implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback
  {
    /**
     * This will be called with the results of the
     * IUnusedAppRestrictionsBackportService.isPermissionRevocationEnabledForApp API.
     * 
     * @param success false if there was an error while checking if the app is
     * enabled, otherwise true.
     * @param isEnabled true if permission revocation is enabled for the app,
     * otherwise false.
     */
    @Override public void onIsPermissionRevocationEnabledForAppResult(boolean success, boolean isEnabled) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback interface,
     * generating a proxy if needed.
     */
    public static androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback))) {
        return ((androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback)iin);
      }
      return new androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_onIsPermissionRevocationEnabledForAppResult:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.onIsPermissionRevocationEnabledForAppResult(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * This will be called with the results of the
       * IUnusedAppRestrictionsBackportService.isPermissionRevocationEnabledForApp API.
       * 
       * @param success false if there was an error while checking if the app is
       * enabled, otherwise true.
       * @param isEnabled true if permission revocation is enabled for the app,
       * otherwise false.
       */
      @Override public void onIsPermissionRevocationEnabledForAppResult(boolean success, boolean isEnabled) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((success)?(1):(0)));
          _data.writeInt(((isEnabled)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_onIsPermissionRevocationEnabledForAppResult, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onIsPermissionRevocationEnabledForAppResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  public static final java.lang.String DESCRIPTOR = "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback";
  /**
   * This will be called with the results of the
   * IUnusedAppRestrictionsBackportService.isPermissionRevocationEnabledForApp API.
   * 
   * @param success false if there was an error while checking if the app is
   * enabled, otherwise true.
   * @param isEnabled true if permission revocation is enabled for the app,
   * otherwise false.
   */
  public void onIsPermissionRevocationEnabledForAppResult(boolean success, boolean isEnabled) throws android.os.RemoteException;
}
